import React from 'react';
import logo from './logo.svg';
import './App.css';
import Home from './container/home/home';

function App() {
  return (
    <div>
          <Home/>
    </div>
  );
}

export default App;
